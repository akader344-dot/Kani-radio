# KANI RADIO — Android project

A starter Android internet-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features included
- Dark KANI RADIO interface
- Add a station using its direct HTTPS stream URL
- Play/pause internet radio
- Media3 playback service for background playback and Android media notification/session integration
- Favourite toggle UI

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Add stations
Tap the + icon and enter:
- A station display name
- A direct HTTPS audio stream URL (for example, a provider-supplied `.mp3`, `.aac`, `.m3u8`, or compatible stream endpoint)

A station's website URL is usually not the audio stream URL. Use only streams you are authorized to access.

## Notes / next steps
- The starter list is intentionally empty because stream URLs and licensing vary by station and country.
- This starter keeps station data in memory; persistence, searchable station directory, sleep timer, and a polished favourites screen can be added next.
- Test background playback and notification behavior on a physical Android device.
