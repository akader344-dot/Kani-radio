package com.kani.radio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private val Ink = Color(0xFF101827)
private val Gold = Color(0xFFE7B85C)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
        }, { command -> command.run() })

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, background = Ink, surface = Color(0xFF1B2638),
                onBackground = Color.White, onSurface = Color.White
            )) {
                RadioHome(
                    onPlay = { url -> playStream(url) },
                    onPause = { mediaController?.pause() }
                )
            }
        }
    }

    private fun playStream(url: String) {
        if (url.isBlank()) return
        val player = mediaController ?: return
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
fun RadioHome(onPlay: (String) -> Unit, onPause: () -> Unit) {
    var stations by remember { mutableStateOf(starterStations) }
    var selected by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var stationName by remember { mutableStateOf("") }
    var stationUrl by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    val current = stations.getOrNull(selected)

    Column(
        Modifier.fillMaxSize().background(Ink).statusBarsPadding().padding(horizontal = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Radio, null, tint = Gold, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("KANI RADIO", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("YOUR MUSIC. YOUR FREQUENCY.", fontSize = 10.sp, color = Gold, letterSpacing = 2.sp)
            }
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add station", tint = Color.White) }
        }

        Box(
            Modifier.fillMaxWidth().height(235.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF263A55), Color(0xFF121D2D))), RoundedCornerShape(28.dp))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("NOW PLAYING", color = Gold, fontSize = 11.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(16.dp))
                Text(current?.name ?: "KANI RADIO", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(current?.subtitle ?: "Internet Radio", color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(24.dp))
                FilledIconButton(
                    onClick = {
                        if (playing) { onPause(); playing = false }
                        else { current?.let { onPlay(it.streamUrl); playing = it.streamUrl.isNotBlank() } }
                    },
                    modifier = Modifier.size(66.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold, contentColor = Ink)
                ) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", modifier = Modifier.size(38.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(if (playing) "LIVE STREAM" else "READY TO PLAY", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("RADIO STATIONS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text("${stations.count { it.streamUrl.isNotBlank() }} STATIONS", color = Gold, fontSize = 11.sp)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(stations) { index, station ->
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF1B2638), RoundedCornerShape(16.dp))
                        .clickable { selected = index; if (station.streamUrl.isNotBlank()) { onPlay(station.streamUrl); playing = true } }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(44.dp).background(Color(0xFF30445F), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Radio, null, tint = Gold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(station.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(station.subtitle, color = Color.LightGray, fontSize = 12.sp)
                    }
                    IconButton(onClick = {
                        favorites = if (station.name in favorites) favorites - station.name else favorites + station.name
                    }) {
                        Icon(if (station.name in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "Favourite", tint = if (station.name in favorites) Gold else Color.LightGray)
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add radio station") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(stationName, { stationName = it }, label = { Text("Station name") }, singleLine = true)
                    OutlinedTextField(stationUrl, { stationUrl = it }, label = { Text("Stream URL (https://...)") }, singleLine = true)
                    Text("Use a direct, legal internet-radio stream URL (not just a station website).", fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (stationName.isNotBlank() && stationUrl.startsWith("https://")) {
                        stations = stations.filter { it.streamUrl.isNotBlank() } +
                            RadioStation(stationName.trim(), "Online radio", stationUrl.trim())
                        selected = stations.lastIndex
                        stationName = ""; stationUrl = ""; showAdd = false
                    }
                }) { Text("ADD") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("CANCEL") } }
        )
    }
}
