package com.kani.radio

data class RadioStation(
    val name: String,
    val subtitle: String,
    val streamUrl: String
)

// Add your own legal station stream URLs here, or use the + button in the app.
val starterStations = listOf(
    RadioStation("Add your first station", "Paste an online radio stream URL", "")
)
